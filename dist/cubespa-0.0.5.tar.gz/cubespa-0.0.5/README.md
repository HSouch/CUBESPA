# CUBE SPectral Analysis

Take your datacubes to the spa for complete analysis.